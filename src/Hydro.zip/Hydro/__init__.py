"""Hydrology package."""

# Install Tqdm if necessary
import importlib.util
import subprocess
import sys

if importlib.util.find_spec("tqdm") is None:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "tqdm", "--quiet"])

# Define main paths to DataLake
from pathlib import Path

import warnings

# Filter out the specific Spark DecimalType conversion warning
warnings.filterwarnings(
    "ignore", 
    message=".*The conversion of DecimalType columns is inefficient.*"
)


class Config:

    HOME = Path("/Workspace/Users/mauricio@ana.gov.br/")
    SGH_RAW = Path("/dbfs/mnt/dlsanaprod001/rawzone/SGH/")
    SGH_GOLD = Path("/dbfs/mnt/dlsanaprod001/goldzone/SGH/")
    SGH_SILVER = Path("/dbfs/mnt/dlsanaprod001/silverzone/SGH/")

    @classmethod
    def convert_path(cls, path):
        return Path("/", path.relative_to("/dbfs")).as_posix()
