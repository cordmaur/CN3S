"""Main functions to be used in Duration Curves package"""

from pathlib import Path
from typing import Literal, TypeAlias
from functools import cache

import pandas as pd 
from pyspark.sql import DataFrame, SparkSession

from . import Config

# User defined types
Source: TypeAlias = Literal["hidro", "telemetria", "hidro/telemetria"]
SeriesType: TypeAlias = Literal["cota", "vazao"]
DataStatus: TypeAlias = Literal["raw", "validated", "combined"]

class Hidro:

    HIDRO_RAW = Path(Config.SGH_RAW) / "HIDRO"
    HIDRO_GOLD = Path(Config.SGH_GOLD) / "HIDRO"
    HIDRO_SILVER = Path(Config.SGH_SILVER) / "HIDRO"


    def __init__(self):
        """
        Initialize Hidro class and load Spark datasets.

        Loads Spark datasets and converts curves to pandas DataFrame.
        """
        self.spark = SparkSession.builder.getOrCreate()
        self._load_spark_datasets()

        # Considering the curves is a much smaller dataset, let's load it into memory
        self.curves = self.stage_curve_spark.toPandas()

    def _load_spark_datasets(self):
        """
        Load Spark datasets for discharges, stages, and stage curves.

        Loads datasets from specified paths and assigns them to class attributes.
        """
        stage_curve_path = Config.convert_path(Hidro.HIDRO_RAW / "tb_curvadescarga.parquet")
        stages_path = Config.convert_path(Hidro.HIDRO_GOLD / "tb_pivot_cotas")
        discharges_path = Config.convert_path(Hidro.HIDRO_GOLD / "tb_pivot_vazoes")
        stations_path = Config.convert_path(Hidro.HIDRO_RAW / "tb_estacao.parquet")

        self.discharges_spark = self.spark.read.format("delta").load(discharges_path)
        self.stages_spark = self.spark.read.format("delta").load(stages_path)
        self.stage_curve_spark = self.spark.read.format("parquet").load(stage_curve_path)
        self.stations_spark = self.spark.read.format("parquet").load(stations_path)

    def _get_spark_dataset(self, series_type: SeriesType) -> DataFrame:
        """
        Return Spark dataset based on series type.

        Parameters:
        series_type : Series type ("cota" or "vazao")

        Returns:
        DataFrame
            Spark DataFrame corresponding to the series type.

        Raises
        ValueError
            If series type is not "cota" or "vazao".

        """
        if series_type == "cota":
            return self.stages_spark
        elif series_type == "vazao":
            return self.discharges_spark
        else:
            raise ValueError("Series type must be either 'cota' or 'vazao'.")

    # --------------- PUBLIC METHODS --------------
    @cache
    def get_series(self, station: int, series_type: SeriesType, data_status: DataStatus = "combined") -> pd.DataFrame | None:
        """
        Return pandas DataFrame with series data for a station.

        Parameters:
        station : Station code
        series_type : Series type ("cota" or "vazao")
        data_status : Data status ("raw", "validated", or "combined"), default is "combined"

        Returns:
        pd.DataFrame or None
            DataFrame with series data or None if no data found.

        Raises:
        ValueError
            If data status is not valid.
        """
        # Get correct spark dataframe depending on series type
        sdf = self._get_spark_dataset(series_type)

        sdf = sdf.filter(sdf.EstacaoCodigo == station)

        # Return if result is empty
        if sdf.count() == 0:
            return None
        
        # Convert to pandas
        df = sdf.toPandas()

        # Combine raw and consisted data into one single time-series
        df = df[df["MediaDiaria"] == 1]
        
        # Ignore discharge = 0
        # if series == "vazao": 
        #     df = df[df["vazao_val"] > 0]
        
        # Convert Data to datetime
        df["Data"] = pd.to_datetime(df[f"{series_type}_data"], format="%Y-%m-%d")
        
        # Let's completely ignore the RAW data
        if data_status == "combined":
            df = df.sort_values(by=["Data", "NivelConsistencia"]).groupby("Data").last()
        elif data_status == "raw":
            df = df[df["NivelConsistencia"] == 1].set_index("Data")
        elif data_status == "validated":
            df = df[df["NivelConsistencia"] == 2].set_index("Data")
        else:
            raise ValueError("Data status must be either 'raw', 'validated', or 'combined'.")
        
        # Convert columns to integer
        date_strs = ["mes", "dia", "ano"]
        cols_to_int = [f"{series_type}_{d}" for d in date_strs]

        # Make sure to avoid any NaN values in these columns
        df = df.dropna(subset=cols_to_int)
        df[cols_to_int] = df[cols_to_int].astype("int")
        df["Sistema"] = "Hidro"

        rename_cols = {f"{series_type}_{d}": d for d in date_strs + ["val"]}
        return df.rename(columns=rename_cols)

    @staticmethod
    def flow_from_stage(H, A, H0, n):
        """
        Compute discharge from stage.

        Parameters:
        H : Stage value(s)
        A : Coefficient
        H0 : Stage offset
        n : Exponent

        Returns:
        Discharge value(s)
        """
        return A * (H - H0) ** n

    @staticmethod
    def stage_from_flow(Q, A, H0, n):
        """
        Compute stage from discharge (inverse rating curve).

        Parameters:
        Q : Discharge value(s)
        A : Coefficient
        H0 : Stage offset
        n : Exponent

        Returns:
        Stage value(s)
        """
        return H0 + (Q / A) ** (1.0 / n)

    def compute_stage_from_flow(self, Q: pd.Series, station: int, ignore_error: bool = False) -> pd.Series:
        """
        Retrieve stage from discharge for a station.

        Parameters:
        Q : Discharge series
        station : Station code
        ignore_error : Whether to ignore if the lenghts of stages and discharges differ

        Returns:
            Stage series, maintaining the same index as Q.

        Raises:
        ValueError
            If equation type is not supported.

        """
        curves = self.curves
        
        # We need to compute every curve to check if stage is within validity range.
        valid_curves = curves[curves["EstacaoCodigo"] == station].sort_values("TipoEquacao")

        # If we find duplicated curves, keep only the last one
        valid_curves = valid_curves.groupby("NumeroCurva").last()

        # Iterate through curves and return first valid stage
        stages_list = []
        for _, curve in valid_curves.iterrows():
            if curve["TipoEquacao"] != 1:
                raise ValueError("Única equação suportada é a tipo 1: Q = A * (H - H0) ** n")

            # extend validity of the curve
            if curve["CotaMinima"] == valid_curves["CotaMinima"].min():
                curve["CotaMinima"] = 0.8 * curve["CotaMinima"] if curve["CotaMinima"] > 0 else 1.2 * curve["CotaMinima"]
                
            if curve["CotaMaxima"] == valid_curves["CotaMaxima"].max():
                curve["CotaMaxima"] = 1.2 * curve["CotaMaxima"]

            stages = 100 * Hidro.stage_from_flow(Q, curve["CoefA"], curve["CoefH0"], curve["CoefN"])
            stages = stages.astype("int")
            stages = stages[(stages >= curve["CotaMinima"]) & (stages <= curve["CotaMaxima"])]
            stages_list.append(stages)

        # At the end, concat the stages
        stages = pd.concat(stages_list, axis=0).sort_index()

        # If, by any chance, we have duplicated stages, we can average them.
        stages = stages.groupby(level=stages.index.names).mean()

        # And if we have a different lenght for the stages and the discharges, we raise an error
        if not ignore_error and len(stages) != len(Q):
            msg = f"{station}: Discharge and stage series have different lengths: {len(Q)} != {len(stages)}"
            raise ValueError(msg)

        return stages
    