from typing import TypeAlias
import pandas as pd

from .hidro import Hidro, SeriesType, DataStatus, Source
from .telemetria import Telemetria
from .hydro_stats import HydroStats

hidro = Hidro()
telemetria = Telemetria()
hydro_stats = HydroStats(hidro)

DataSanitization: TypeAlias = dict[SeriesType, dict[str, float]]

class Station:
    """
    Aggregates all information hydrological and inventory about a station into one place.
    Once a station is instantiated, it loads the series from Hidro and from Telemetria databases.
    """

    def __init__(self, code: int, sanitization: DataSanitization | None = None):
        
        self.code, self.info = Station.load_station_info(code)
        # self.info = hydro_stats.get_station_stats(code)

        self.sanitization = sanitization

        self.load_telemetric_info()

        self.load_series()

        self.calc_stats()

    def load_telemetric_info(self) -> None:
        self.telemetric_info = telemetria.get_telemetric_code(self.code)

    @property
    def name(self) -> str:
        return self.info["Nome"].iloc[0]

    @staticmethod
    def load_station_info(code: int) -> tuple[int, pd.DataFrame]:
        stations = hidro.stations_spark
        df = stations.filter(stations["Codigo"] == code).toPandas()

        if len(df) == 0:
            msg = f"Station {code} not found in Hidro"
            raise ValueError(msg)

        return code, df

    def load_series(self) -> None:
        self.series = {
            self.code: {
                "cota": hidro.get_series(self.code, "cota", "combined"),
                "vazao": hidro.get_series(self.code, "vazao", "combined"),
            }            
        }

        # Skip if there is no telemetric station with this code
        if self.telemetric_info is None:
            return
        
        for telemetric_code in self.telemetric_info.index:
            self.series[telemetric_code] = {
                "cota": telemetria.get_series(telemetric_code, "cota"),
                "vazao": telemetria.get_series(telemetric_code, "vazao")
            }

    def get_source(self, station_code: int) -> str:
        if (self.telemetric_info is not None) and (station_code in self.telemetric_info.index):
            return "Telemetria/" + self.telemetric_info.loc[station_code, "OGMORGAO"]
        else:
            return "Hidro"

    def calc_stats(self) -> None:

        # Init an empty dataframe
        stats_df = pd.DataFrame()

        for code in self.series.keys():
            source = self.get_source(code)
            stats = {
                "cota": HydroStats.calc_series_stats(
                    self.series[code]["cota"], 
                    "val", 
                    "NivelConsistencia" if source == "Hidro" else None
                ),
                "vazao": HydroStats.calc_series_stats(
                    self.series[code]["vazao"], 
                    "val", 
                    "NivelConsistencia" if source == "Hidro" else None
                ),
            }

            df = pd.DataFrame(stats).unstack().to_frame().T
            df.index = [code]
            df["Fonte"] = source


            stats_df = pd.concat([stats_df, df], axis=0)

        stats_df.index.name = "EstacaoCodigo"

        self.stats = stats_df[["Fonte", "cota", "vazao"]]

    @staticmethod
    def _create_description(source: str | list[str], stats: pd.Series) -> str:
        stats = stats[["Inicio", "Fim", "Anos", "Falhas (%)", "Consist (%)"]]
        s = " ".join([f"{k}:{v}" for k, v in stats.items()])

        if not isinstance(source, str):
            source = "/".join(source)

        s = source.upper() + " - " + s.replace(" (", "(")

        return s

    def get_series(
        self, source: Source,
        series_type: SeriesType,
        period: slice = slice(None, None),
    ) -> tuple[pd.DataFrame, pd.Series]:

        dfs = []
        if "hidro" in source:
            dfs.append(self.series[self.code][series_type])


        if "telemetria" in source:
            # Combine telemetric series considering the ORIGIN precedence
            df = pd.concat(
                [self.series[code][series_type] for code in self.telemetric_info.index],
                axis=0,
            )
            
            df = df.reset_index().sort_values(by=['Data', 'ORIGEM'])
            df = df.drop_duplicates(subset=["Data"], keep="first")
            df = df.set_index("Data")
            df["NivelConsistencia"] = 1
            dfs.append(df)

        # Union hidro and telemetria (if that's the case)
        try:
            df = pd.concat(dfs, axis=0)
        except:
            self.descr = f"Sem dados de {series_type}"
            return pd.DataFrame(columns=["val"]), pd.Series()

        df["Sistema"] = pd.Categorical(
            df["Sistema"], 
            categories = ["Hidro", "Telemetria"], 
            ordered=True
        )
        df = df.reset_index().sort_values(by=['Data', 'Sistema'])
        df = df.drop_duplicates(subset=["Data"], keep="first")
        df = df.set_index("Data")

        # apply the period slice
        df = df.loc[period]

        # Sanitization will be applied regardless the source of the data
        if self.sanitization and (series_type in self.sanitization):
            for date, value in self.sanitization[series_type].items():
                df.loc[date, "val"] = value 

        total = len(df)
        used_sources = [
            f"{k}({100*(v/total):.1f}%)" 
            for k, v in df.groupby("Sistema", observed=True).size().items()
        ]

        stats = HydroStats.calc_series_stats(
            df, 
            "val", 
            "NivelConsistencia" if "NivelConsistencia" in df.columns else None
        )

        stats = pd.Series(stats)
        self.descr = Station._create_description(used_sources, stats)

        return df, stats



    