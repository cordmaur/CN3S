from collections.abc import Sequence
from functools import cache

import pandas as pd
from pyspark.sql import DataFrame, SparkSession

from . import Config
from .hidro import SeriesType

class Telemetria:

    PRECEDENCE = [
        'RHN',
        'Setor Elétrico',
        'Setores Regulados',
        'Inpe/Sivam(desativadas)',
        'Poços',
        'CotaOnline',
        'Açudes Semiárido'
    ]

    def __init__(self):
        """Docstring"""
        self.spark = SparkSession.builder.getOrCreate()

        self._load_spark_datasets()

    def _load_spark_datasets(self) -> None:
        """Docstring"""
        spark = self.spark

        # Load Stages table
        stages_path = Config.convert_path(Config.SGH_SILVER / "HIDROINFOANA/tb_cotas")
        self.stages_spark = spark.read.format("delta").load(stages_path)
        # Load Discharges table
        discharges_path = Config.convert_path(Config.SGH_SILVER / "HIDROINFOANA/tb_vazoes")
        self.discharges_spark = spark.read.format("delta").load(discharges_path)

        # Join Stations with Origin
        stations_path = Config.convert_path(Config.SGH_RAW / "HIDROINFOANA/tb_estacao.parquet")
        stations_spark = spark.read.format("parquet").load(stations_path)

        origin_spark = Config.convert_path(Config.SGH_RAW / "HIDROINFOANA/tb_origem.parquet")
        origin_spark = spark.read.format("parquet").load(origin_spark)

        self.origin = origin_spark.toPandas()

        self.stations_spark = stations_spark.join(
            origin_spark,
            on=stations_spark.ESTORIGEM == origin_spark.OGMCODIGO, 
            how="left"
        )

    @cache
    def get_series(self, telemetric_code, series_type: SeriesType) -> pd.DataFrame:
        """Docstring"""
        # Load the dataset to Pandas
        spark_df = self.stages_spark if series_type == "cota" else self.discharges_spark
        df = spark_df.filter(spark_df.HORESTACAO == telemetric_code).toPandas()

        val_col = "HORNIVELADOTADO" if series_type == "cota" else "HORVAZAO"

        # Make sure to avoid any NaN values in these columns
        df["val"] = df[val_col].astype(float)
                
        df["Data"] = pd.to_datetime(df["HORDATAHORA"])
        
        df["HORESTACAO"] = df["HORESTACAO"].astype(int)
        df = df.set_index("Data").resample("1D").mean()
        df = df.dropna(subset=["val"]).copy()
        
        # Get the source of the data
        station = self.stations_spark[self.stations_spark["ESTCODIGO"] == telemetric_code].toPandas()
        df["ORIGEM"] = station.iloc[0]["OGMORGAO"]
        df["ORIGEM"] = pd.Categorical(
            df["ORIGEM"],
            categories=Telemetria.PRECEDENCE,
            ordered=True
        )

        df["Sistema"] = "Telemetria"

        return df


    @cache
    def get_telemetric_code(self, station: int) -> pd.DataFrame | None:
        """Docstring"""
        df = self.stations_spark.filter(self.stations_spark['ESTANEELFLU'] == station).toPandas()

        if len(df) == 0:
            return None
        
        else:
            df["ESTCODIGO"] = df["ESTCODIGO"].astype("int")
            return df[['ESTCODIGO', "OGMORGAO"]].set_index("ESTCODIGO")


    @cache
    def get_telemetric_name(self, telemetric_code: int) -> str:
        """Docstring."""
        df = self.stations_spark.filter(self.stations_spark['ESTCODIGO'] == telemetric_code).toPandas()
        if len(df) == 1:
            return df["ESTNOME"].iloc[0]
        else:
            return "Não encontrado"

    




    
